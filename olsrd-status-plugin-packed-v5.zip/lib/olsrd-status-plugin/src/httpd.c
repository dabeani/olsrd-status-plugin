#include "httpd.h"
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

static http_handler_node_t *match_handler(http_server_t *srv, const char *path) {
  for (http_handler_node_t *n = srv->handlers; n; n = n->next) {
    if (n->path && path && strcmp(n->path, path) == 0) return n;
  }
  return NULL;
}

int http_server_init(http_server_t *srv) {
  if (!srv) return -1;
  srv->running = 0;
  srv->listen_fd = -1;
  srv->handlers = NULL;
  return 0;
}

int http_server_register_handler(http_server_t *srv, const char *path, http_handler_t cb) {
  if (!srv || !path || !cb) return -1;
  http_handler_node_t *n = (http_handler_node_t*)calloc(1, sizeof(*n));
  if (!n) return -1;
  n->path = path;
  n->cb = cb;
  n->next = srv->handlers;
  srv->handlers = n;
  return 0;
}

/* very tiny request parser for GET /path HTTP/1.1 */
static int parse_request_line(int fd, char *method, size_t msz, char *path, size_t psz) {
  char buf[4096];
  ssize_t r = read(fd, buf, sizeof(buf)-1);
  if (r <= 0) return -1;
  buf[r] = 0;
  if (sscanf(buf, "%7s %1023s", method, path) != 2) return -1;
  method[msz-1] = 0;
  path[psz-1] = 0;
  return 0;
}

static void default_handler(http_request_t *r) {
  const char *msg = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n";
  (void)write(r->fd, msg, strlen(msg));
}

int http_server_start(http_server_t *srv, const char *bind_addr, int port) {
  if (!srv) return -1;
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if (fd < 0) return -1;

  int one = 1; setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

  struct sockaddr_in sa; memset(&sa, 0, sizeof(sa));
  sa.sin_family = AF_INET;
  sa.sin_port = htons((uint16_t)port);
  sa.sin_addr.s_addr = inet_addr(bind_addr && *bind_addr ? bind_addr : "0.0.0.0");
  if (bind(fd, (struct sockaddr*)&sa, sizeof(sa)) != 0) { close(fd); return -1; }
  if (listen(fd, 8) != 0) { close(fd); return -1; }

  srv->listen_fd = fd;
  srv->running = 1;

  while (srv->running) {
    http_request_t req; memset(&req, 0, sizeof(req));
    req.peer_len = sizeof(req.peer);
    int cfd = accept(fd, (struct sockaddr*)&req.peer, &req.peer_len);
    if (cfd < 0) {
      if (errno == EINTR) continue;
      break;
    }
    req.fd = cfd;

    char method[8]={0}, path[1024]={0};
    if (parse_request_line(cfd, method, sizeof(method), path, sizeof(path)) == 0) {
      http_handler_node_t *hn = match_handler(srv, path);
      if (hn && hn->cb) hn->cb(&req);
      else default_handler(&req);
    }
    close(cfd);
  }
  close(fd);
  srv->listen_fd = -1;
  return 0;
}

void http_server_close(http_server_t *srv) {
  if (!srv) return;
  srv->running = 0;
  if (srv->listen_fd >= 0) close(srv->listen_fd);
  http_handler_node_t *n = srv->handlers;
  while (n) { http_handler_node_t *nx = n->next; free(n); n = nx; }
  srv->handlers = NULL;
}

int http_send_buf(int fd, int status, const char *ctype, const char *buf, size_t len) {
  char hdr[256];
  int n = snprintf(hdr, sizeof(hdr),
                   "HTTP/1.1 %d OK\r\nContent-Type: %s\r\nContent-Length: %zu\r\n\r\n",
                   status, ctype ? ctype : "text/plain", len);
  if (write(fd, hdr, n) != n) return -1;
  if (len > 0 && write(fd, buf, len) != (ssize_t)len) return -1;
  return 0;
}
