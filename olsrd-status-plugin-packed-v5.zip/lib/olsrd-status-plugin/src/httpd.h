#pragma once
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>

typedef struct http_request {
  int fd;
  struct sockaddr_storage peer;
  socklen_t peer_len;
} http_request_t;

/* send a minimal HTTP response */
int http_send_buf(int fd, int status, const char *ctype, const char *buf, size_t len);

typedef void (*http_handler_t)(http_request_t *r);

typedef struct http_handler_node {
  const char *path;
  http_handler_t cb;
  struct http_handler_node *next;
} http_handler_node_t;

typedef struct http_server {
  int running;
  int listen_fd;
  http_handler_node_t *handlers;
} http_server_t;

int http_server_init(http_server_t *srv);
int http_server_register_handler(http_server_t *srv, const char *path, http_handler_t cb);
int http_server_start(http_server_t *srv, const char *bind_addr, int port);
void http_server_close(http_server_t *srv);
