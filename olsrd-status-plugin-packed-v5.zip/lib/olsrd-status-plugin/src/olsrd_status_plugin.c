#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#include "../../include/olsrd_plugin.h"
#include "../../src/olsrd_plugin.h" /* some trees place it here; ignored if same */
#include "httpd.h"

static int g_port = 11080;
static char g_bind[64] = "0.0.0.0";
static int g_enable_ipv6 = 0;

static pthread_t http_thr;
static int http_running = 0;

static int set_port_cb(const char *v, void *d, set_plugin_parameter_addon a) {
  (void)d; (void)a;
  if (!v || !*v) return 1;
  g_port = atoi(v);
  if (g_port <= 0 || g_port > 65535) return 1;
  return 0; /* OK */
}
static int set_bind_cb(const char *v, void *d, set_plugin_parameter_addon a) {
  (void)d; (void)a;
  if (!v || !*v) return 1;
  strncpy(g_bind, v, sizeof(g_bind)-1);
  g_bind[sizeof(g_bind)-1] = 0;
  return 0; /* OK */
}
static int set_enable_ipv6_cb(const char *v, void *d, set_plugin_parameter_addon a) {
  (void)d; (void)a;
  if (!v) return 0; /* default false */
  if (!strcasecmp(v, "yes") || !strcasecmp(v, "true") || !strcmp(v, "1")) g_enable_ipv6 = 1;
  else g_enable_ipv6 = 0;
  return 0; /* OK */
}

static void handle_root(http_request_t *r) {
  char out[256];
  int n = snprintf(out, sizeof(out),
                   "status plugin ok (bind=%s port=%d ipv6=%s)\n",
                   g_bind, g_port, g_enable_ipv6 ? "on" : "off");
  http_send_buf(r->fd, 200, "text/plain; charset=utf-8", out, (size_t)n);
}

static void *http_loop(void *arg) {
  (void)arg;
  http_server_t srv;
  http_server_init(&srv);
  http_server_register_handler(&srv, "/", handle_root);
  http_running = 1;
  /* IPv6 toggle currently ignored; server binds IPv4 only */
  http_server_start(&srv, g_bind, g_port);
  http_server_close(&srv);
  http_running = 0;
  return NULL;
}

/* --- olsrd plugin glue --- */

int olsrd_plugin_interface_version(void) {
  return 5;
}

static const struct olsrd_plugin_parameters plugin_params[] = {
  { .name = "Port",       .set_plugin_parameter = set_port_cb,        .data = NULL },
  { .name = "Bind",       .set_plugin_parameter = set_bind_cb,        .data = NULL },
  { .name = "EnableIPv6", .set_plugin_parameter = set_enable_ipv6_cb, .data = NULL },
};

void olsrd_get_plugin_parameters(const struct olsrd_plugin_parameters **params, int *size) {
  *params = plugin_params;
  *size = (int)(sizeof(plugin_params) / sizeof(plugin_params[0]));
}

int olsrd_plugin_init(void) {
  pthread_create(&http_thr, NULL, http_loop, NULL);
  return 1; /* non-zero = OK for olsrd */
}

void olsrd_plugin_exit(void) {
  /* Best-effort stop; http_server_start loop ends when process exits */
  (void)http_running;
}


/* --- BEGIN: permissive v5 parameter handling fix (auto-baked) --- */
#include <ctype.h>
#include <string.h>
#include <arpa/inet.h>
#include "olsrd_plugin.h"

/* Storage for parsed parameters (separate from any legacy globals) */
static int status_http_port = 11080;
static struct in_addr status_http_bind; /* zero-init = 0.0.0.0 */
static int status_enable_ipv6 = 0;      /* accepted; currently a no-op */

/* v5 setter signature:
 *   int set(const char *val, void *data, set_plugin_parameter_addon addon)
 * Return 0 on success, non-zero on failure.
 */
static int status_set_bool(const char *val, void *data, set_plugin_parameter_addon addon) {
  (void)addon;
  if (!val || !data) return 1;
  char buf[16]; size_t i=0;
  for (; val[i] && i < sizeof(buf)-1; i++) buf[i] = (char)tolower((unsigned char)val[i]);
  buf[i] = 0;
  if (!strcmp(buf,"1")||!strcmp(buf,"true")||!strcmp(buf,"yes")||!strcmp(buf,"on"))  { *(int*)data = 1; return 0; }
  if (!strcmp(buf,"0")||!strcmp(buf,"false")||!strcmp(buf,"no") ||!strcmp(buf,"off")) { *(int*)data = 0; return 0; }
  return 1;
}

static int status_set_port(const char *val, void *data, set_plugin_parameter_addon addon) {
  (void)addon;
  if (!val || !data) return 1;
  char *end = NULL;
  long p = strtol(val, &end, 10);
  if (end && *end) return 1;
  if (p < 1 || p > 65535) return 1;
  *(int*)data = (int)p;
  return 0;
}

static int status_set_bind_ipv4(const char *val, void *data, set_plugin_parameter_addon addon) {
  (void)addon;
  if (!val || !data) return 1;
  struct in_addr a;
  if (inet_aton(val, &a) == 0) return 1; /* invalid IPv4 */
  *(struct in_addr*)data = a;
  return 0;
}

/* Parameter table exposed to OLSRd v5 */
static const struct olsrd_plugin_parameters status_plugin_parameters[] = {
  { .name = "port",       .set_plugin_parameter = status_set_port,      .data = &status_http_port },
  { .name = "bind",       .set_plugin_parameter = status_set_bind_ipv4, .data = &status_http_bind },
  { .name = "enableipv6", .set_plugin_parameter = status_set_bool,      .data = &status_enable_ipv6 },
};

/* v5 export symbol expected by OLSRd */
int olsrd_plugin_parameters(const struct olsrd_plugin_parameters **params, int *size) {
  if (!params || !size) return 1;
  *params = status_plugin_parameters;
  *size   = (int)(sizeof(status_plugin_parameters)/sizeof(status_plugin_parameters[0]));
  return 0; /* success */
}
/* ---  END: permissive v5 parameter handling fix --- */

