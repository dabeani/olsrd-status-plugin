#!/usr/bin/env bash
set -euo pipefail
f="lib/olsrd-status-plugin/src/olsrd_status_plugin.c"
if [ ! -f "$f" ]; then
  echo "Run from repo root. Missing $f" >&2
  exit 1
fi
# Remove duplicate global definitions, keep the first ones
# This is a very conservative filter that keeps the first match of each declaration.
awk '
  BEGIN{seen_gport=0; seen_gbind=0; seen_gipv6=0}
  /static int g_port =/ { if(seen_gport++) next }
  /static char g_bind\[64\] =/ { if(seen_gbind++) next }
  /static int g_enable_ipv6 =/ { if(seen_gipv6++) next }
  {print}
' "$f" > "$f.tmp" && mv "$f.tmp" "$f"
echo "Done. Duplicates (if any) removed."
