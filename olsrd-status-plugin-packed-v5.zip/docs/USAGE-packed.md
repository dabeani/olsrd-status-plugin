# OLSRd Status Plugin (packed v5)
- v5 param handling is pre-integrated in source (no patching needed)
- Build just the plugin:
    make -C lib/olsrd-status-plugin clean all
- Install:
    make -C lib/olsrd-status-plugin install DESTDIR=/
- olsrd.conf example:
    LoadPlugin "lib/olsrd-status-plugin/build/olsrd_status.so.1.0"
    {
      PlParam "bind"       "0.0.0.0"
      PlParam "port"       "11080"
      PlParam "enableipv6" "no"
    }
