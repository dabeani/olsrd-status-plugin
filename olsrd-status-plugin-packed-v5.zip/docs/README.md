# olsrd-status-plugin

A tiny status HTTP plugin for OLSRd (interface v5). IPv4-only bind; IPv6 toggle accepted but currently a no-op.

## Build (single plugin)
```sh
make status_plugin_clean && make status_plugin
```

## Install
```
make status_plugin_install DESTDIR=/
```

## olsrd.conf
```
LoadPlugin "lib/olsrd-status-plugin/build/olsrd_status.so.1.0"
{
  PlParam "bind"       "0.0.0.0"
  PlParam "port"       "11080"
  PlParam "enableipv6" "no"
}
```

## Test
```
curl http://127.0.0.1:11080/
```
